﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;
using System.Linq;
using System.Text;


namespace DataRW
{
    public partial class DataRW : Form
    {
        /// <summary>
        /// iniファイル読込設定
        /// </summary>
        /// <param name="lpAppName"></param>
        /// <param name="lpKeyName"></param>
        /// <param name="lpDefault"></param>
        /// <param name="lpReturnedString"></param>
        /// <param name="nSize"></param>
        /// <param name="lpFileName"></param>
        /// <returns></returns>
        [DllImport("kernel32.dll", EntryPoint = "GetPrivateProfileStringW", CharSet = CharSet.Unicode, SetLastError = true)]
        static extern uint GetPrivateProfileString(string lpAppName, string lpKeyName, string lpDefault, StringBuilder lpReturnedString, uint nSize, string lpFileName);

        private string fln1 = @"./DataRW.ini";

        private string DBRpath;

        /// <summary>
        /// 初期設定
        /// </summary>
        public DataRW()
        {
            InitializeComponent();

            //フォーム画面設定
            ControlBox = false;

            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            DGVData.ReadOnly = true;

            DGVSort.ReadOnly = true;

            DGVData.RowHeadersWidth = 80;

            DGVSort.RowHeadersWidth = 80;

            //数値入力のみ設定
            cbFile.Click += new EventHandler(cbFile_Click);
            cbFile.TextChanged += new EventHandler(cbFile_TextChanged);

            tbColNum.KeyPress += new KeyPressEventHandler(tbColNum_KeyPress);

            tbSortNum.KeyPress += new KeyPressEventHandler(tbSortNum_KeyPress);


            //iniファイル読込失敗時
            int capacitySize = 256;

            if (!File.Exists(fln1))
            {
                MessageBox.Show("iniファイルが見当たりません");

                //各種ボタンを非活性
                DGVData.Enabled = true;

                tbFile.Enabled = true;

                cbFile.Enabled = false;

                btnIncCol.Enabled = false;

                btnDecCol.Enabled = false;

                btnRead.Enabled = false;

                btnOpenDir.Enabled = false;

                btnWrite.Enabled = false;

                tbWriteName.Enabled = false;

                btnRead.Enabled = false;
                
                tbColName.Enabled = false;

                tbColNum.Enabled = false;

                btnSetCol.Enabled = false;

                tbSortNum.Enabled = false;

                btnSortRun.Enabled = false;
            }

            //iniファイル読込成功時
            else
            {
                StringBuilder sb = new StringBuilder(capacitySize);

                GetPrivateProfileString("pathdata", "pn1", "", sb, Convert.ToUInt32(sb.Capacity), fln1);

                DBRpath = @sb.ToString();

                DGVData.Enabled = true;

                tbFile.Enabled = true;

                cbFile.Enabled = false;

                btnIncCol.Enabled = false;

                btnDecCol.Enabled = false;

                btnRead.Enabled = false;

                btnOpenDir.Enabled = true;

                btnWrite.Enabled = false;

                tbWriteName.Enabled = false;

                btnRead.Enabled = false;

                tbColName.Enabled = false;

                tbColNum.Enabled = false;

                btnSetCol.Enabled = false;

                tbSortNum.Enabled = false;

                btnSortRun.Enabled = false;
            }
        }

        /// <summary>
        /// 読込ファイルの場所が不明の場合
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOpenDir_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("EXPLORER.EXE", DBRpath);
        }

        /// <summary>
        ///リストボックスで読込ファイルのリストクリックした場合
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbFile_Click(object sender, EventArgs e)
        {
            //リストのクリア
            cbFile.Items.Clear();

            //指定ファイル名に応じた相対パスをリスト表示
            string[] filepath = Directory.GetFiles(DBRpath, tbFile.Text, SearchOption.AllDirectories);

            for (int i = 0; i < filepath.Length; i++)
            {
                cbFile.Items.Add(filepath[i]);
            }
        }
        /// <summary>
        /// リストボックスから列編集を開く
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbFile_TextChanged(object sender, EventArgs e)
        {
            if (cbFile.Text.Contains("."))
            {
                btnIncCol.Enabled = true;

                btnDecCol.Enabled = true;

                tbColName.Enabled = true;

                tbColNum.Enabled = true;

                btnSetCol.Enabled = true;
            }
            else if (!cbFile.Text.Contains("."))
            {
                btnIncCol.Enabled = false;

                btnDecCol.Enabled = false;

                tbColName.Enabled = false;

                tbColNum.Enabled = false;

                btnSetCol.Enabled = false;
            }
        }

        /// <summary>
        /// リストボックスからファイル選択
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbFile_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbFile.Text != "読込ファイル一覧")
            {
                StreamReader DB_R1 = new StreamReader(cbFile.Text, Encoding.GetEncoding("shift_jis"));

                if (DGVData.Columns.Count == Convert.ToInt32(DB_R1.ReadLine().Split(' ').Count() + 1))
                {
                }
                else if (File.Exists(cbFile.Text))
                {
                    MessageBox.Show("下記で列数を指定\n" +
                        "読込ファイルの列数：" + Convert.ToString(DB_R1.ReadLine().Split(' ').Count() + 1));

                }
            }
        }

        /// <summary>
        /// 読込開始ボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRead_Click(object sender, EventArgs e)
        {
            //csvからgrid dataviewへ：gridの初期化→入力
            //DGVData.Rows.Clear();

            //ファイル名の相違
            if (!File.Exists(Convert.ToString(DBRpath + cbFile.Text)))
            {
                MessageBox.Show("ファイルパスを確認してください");
            }
           //パスマッチの場合
            else
            {
                StreamReader DB_R1 = new StreamReader(cbFile.Text, Encoding.GetEncoding("shift_jis"));

                //列数不一致
                if (DGVData.Columns.Count != DB_R1.ReadLine().Split(' ').Count() + 1)
                {
                    MessageBox.Show("列数がマッチしません\n" +
                        "読込データ列数：" + Convert.ToString(DB_R1.ReadLine().Split(' ').Count() + 1)+"\n"+"\n"+
                        "列数の増減が必要な場合，「読込書込先フォルダ確認」より，" +
                        "       \nファイルの編集をしてから読み込みしてください\n" );

                DB_R1.Close();
                }
                //列数一致
                else
                {
                   
                    StreamReader DB_R2 = new StreamReader(cbFile.Text, Encoding.GetEncoding("shift_jis"));
                    
                    //先頭の見出し行は削除
                    DB_R2.ReadLine();
                    
                         //DGVData.Columns.RemoveAt(Convert.ToInt32(tbSetCol.Text));
                         while (DB_R2.EndOfStream == false)
                         {
                            string DB_R3 = DB_R2.ReadLine();
                    
                             string DB_R4 = DB_R3;
                    
                             string[] DB_R5 = DB_R4.Split(',');
                    
                             DGVData.Rows.Add(DB_R5);
                       // DGVData.Rows.Insert(DGVData.Rows.Count-1);
                    
                    }
                    DB_R2.Close();

                    //griddataに行番号を入力
                    for (int j = 0; j < DGVData.Rows.Count - 1; j++)
                    {
                        DGVData.Rows[j].HeaderCell.Value = Convert.ToInt32(DGVData[0,j].Value).ToString();
                    }

                    btnRead.Refresh();

                    //読込後の処理
                    DB_R1.Close();

                    cbFile.Text = "";

                    tbFile.Text = "";

                    tbSortNum.Enabled = true;

                    btnSortRun.Enabled = true;
                }
            }
        }

        /// <summary>
        ///読込ファイル記入欄
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbFile_TextChanged(object sender, EventArgs e)
        {
            cbFile.Enabled = true;
        }

        /// <summary>
        /// 列数増加ボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnIncCol_Click_1(object sender, EventArgs e)
        {
                DGVData.Columns.Add("", "");
    
                DGVSort.Columns.Add("", "");

        }

        /// <summary>
        /// 列数削除ボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDecCol_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(DGVData.Columns.Count)-1 == -1)
            {
            MessageBox.Show("列を削除できません");
            }
            else if(Convert.ToInt32(DGVData.Columns.Count)-1 >=1)
            {
                DGVData.Columns.RemoveAt(Convert.ToInt32(DGVData.Columns.Count)-1 );

                DGVSort.Columns.RemoveAt(Convert.ToInt32(DGVData.Columns.Count) -1);
            }
            else if(Convert.ToInt32(DGVData.Columns.Count) - 1 ==0)
            {
                DGVData.Columns.RemoveAt(0);

                DGVSort.Columns.RemoveAt(0);
            }
            else
            {
                MessageBox.Show("列を減らせません");
            }
        }

        /// <summary>
        /// 列数入力：0-9　バックスペース以外不可
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbColNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            //0～9と、バックスペース以外の時は、イベントをキャンセルする
            if ((e.KeyChar < '0' || '9' < e.KeyChar) && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// 列設定
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSetCol_Click(object sender, EventArgs e)
        {
            if (tbColNum.Text=="列番号")
            {
                MessageBox.Show("半角数字のみ：数値キー入力"+"\n"+
                    "入力範囲：0から設定列数");

                tbColNum.Text = "";
            }
            //そうでない場合
            else
            {
                //数値が空の場合
                if (tbColNum.Text == "")
                {
                    MessageBox.Show("列数を入力");
                }
                //そうでない場合
                else
                {
                    //文字入力規制
                    if (tbColNum.Text.Length >= 2 && tbColNum.Text.StartsWith("0"))
                    {
                        MessageBox.Show("00，01，001などは不可");
                        tbColNum.Text = "";
                    }

                    //正常入力時
                    else
                    {
                        //入力数字規制
                        if (Convert.ToInt32(tbColNum.Text) >= Convert.ToInt32(DGVData.Columns.Count))
                        {
                            MessageBox.Show("列数を増やしてください");

                        }

                        //入力範囲正常時
                        else if (Convert.ToInt32(tbColNum.Text) < Convert.ToInt32(DGVData.Columns.Count))
                        {
                            DGVData.Columns[Convert.ToInt32(tbColNum.Text)].HeaderText = tbColName.Text;

                            DGVSort.Columns[Convert.ToInt32(tbColNum.Text)].HeaderText = tbColName.Text;
                        }

                        if (DGVData.Columns[Convert.ToInt32(DGVData.Columns.Count-1)].HeaderText != "")
                        {
                            btnRead.Enabled = true;
                        }
                        else
                        {
                            btnRead.Enabled = false;
                        }
                    }
                }
            }
            if (DGVData.Columns[Convert.ToInt32(DGVData.Columns.Count - 1)].HeaderText == "")
            {
                btnRead.Enabled = false;
            }
        }

        /// <summary>
        /// 並べ替え入力：0-9　バックスペース以外不可
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbSortNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            //0～9と、バックスペース以外の時は、イベントをキャンセルする
            if ((e.KeyChar < '0' || '9' < e.KeyChar) && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
        }

        /// <summary>
        /// 並べ替え実行ボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSortRun_Click(object sender, EventArgs e)
        {
            //入力数値が列数を超える場合
            if (Convert.ToInt32(tbSortNum.Text)> DGVData.Columns.Count)
            {
                MessageBox.Show("指定番号が大きすぎます\n"+"0から"+ (DGVData.Columns.Count - 1) +"の範囲");
            }

            //列番号，正常入力時
            else if(Convert.ToInt32(tbSortNum.Text) ==0)//< Convert.ToInt32(DGVData.Columns.Count))
            {
                //並替作業
                //配列で参照
                int[] datsort1 = new int[DGVData.Rows.Count-1];

                for (int i = 0; i < DGVData.Rows.Count - 1; i++)
                {
                    datsort1[i] = Convert.ToInt32(DGVData.Rows[i].Cells[0].Value);
                }

                int datmax1;
                datmax1 = datsort1.Max();

                int[] datsort2 = new int[datmax1];
                for (int i =0;i<datmax1;i++)
                {
                    datsort2[i] = i;
                }

                DGVSort.Rows.Add(datmax1+1); 

                //格納
                for (int i =0; i<=datmax1; i++)
                {
                    for (int k =0; k< datsort1.Length; k++)
                    {
                        if (i.ToString()== datsort1[k].ToString())
                        {
                            for (int j =0; j < DGVData.Columns.Count; j++)
                            {
                                DGVSort.Rows[i].Cells[j].Value = DGVData.Rows[k].Cells[j].Value;

                                DGVSort.Rows[i].HeaderCell.Value = 
                                    Convert.ToInt32(DGVSort.Rows[i].Cells[0].Value).ToString();
                            }
                        }
                    }

                    //空行なら，その行を非表示
                    if (DGVSort.Rows[i].HeaderCell.Value == null)
                    {
                        DGVSort.Rows[i].Selected = true;
                    }
                }

                //選択した空白行を削除
                foreach (DataGridViewRow item in DGVSort.SelectedRows)
                {
                    DGVSort.Rows.Remove(item);
                }
                ///インデックス番号
                //書き込み用ボタンを活性
                tbWriteName.Enabled = true;

                btnWrite.Enabled = true;
            }
            else
            {
                MessageBox.Show("未設定");
            }
        }

        /// <summary>
        /// 書込開始ボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnWrite_Click(object sender, EventArgs e)
        {
            //ファイル名不可
            if (!(tbWriteName.Text.Contains(".")))
            {
                MessageBox.Show("拡張子を記入してください：.txt, .csv等");
            }
            //そうでない場合
            else
            {
                // 書き込み用CSVファイルの作成と既存ファイルの初期化
                StreamWriter DB_W1 = new StreamWriter(Convert.ToString(DBRpath + 
                        "書込用並替済_" + tbWriteName.Text), false, Encoding.UTF8);

                //列名指定
                for (int i =0; i < DGVSort.Columns.Count; i++)
                {
                    DB_W1.Write(DGVSort.Columns[i].HeaderText + ",");
                }
                DB_W1.Write("\n");
                //行数
                for (int i = 0; i < DGVSort.RowCount - 1; i++)
                {
                    //列数
                    for (int j = 0; j < DGVSort.ColumnCount; j++)
                    {
                        //カンマ区切り
                        //DB_W1.Write(String.Format("{0:000}", Convert.ToInt32(DGVSort[j, i].Value))+",");

                        string datwrite1 = DGVSort[j, i].Value.ToString();

                        int datwrite2=0;

                        if (int.TryParse(datwrite1, out datwrite2) == true)
                        {
                            DB_W1.Write("'" + DGVSort[j, i].Value + ",");
                        }
                        else if (int.TryParse(datwrite1, out datwrite2) == false)
                        {
                            datwrite1 = DGVSort[j, i].Value.ToString();

                            DB_W1.Write(datwrite1 + ",");
                        }
                    }

                    DB_W1.WriteLine();
                }
                MessageBox.Show("書き込み先\n" + Convert.ToString(DBRpath + "書込用並替済_" + tbWriteName.Text));

                DB_W1.Close();

                // データをすべてクリア
                DGVData.Rows.Clear();

                DGVSort.Rows.Clear();
            }

            btnWrite.Enabled = false;

            tbWriteName.Enabled = false;

            btnSortRun.Enabled = false;

            tbSortNum.Enabled = false;

            btnIncCol.Enabled = false;

            btnDecCol.Enabled = false;
            
            tbColNum.Enabled = false;
            
            tbColName.Enabled = false;

            btnSetCol.Enabled = false;

            btnRead.Enabled = false;
        }

        /// <summary>
        /// 閉じるボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        ///不要だがないと，デザインが機能しない
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbSetCol_TextChanged_1(object sender, EventArgs e)
        {
        }
        private void DGVData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }
        private void tbSetCol_TextChanged(object sender, EventArgs e)
        {
        }
        private void DataRW_Load(object sender, EventArgs e)
        {
        }
        private void tbWriteName_TextChanged(object sender, EventArgs e)
        {
        }
        private void tbColNum_TextChanged(object sender, EventArgs e)
        {
        }
        private void tbColName_TextChanged(object sender, EventArgs e)
        {
        }
        private void DGVSort_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }
        private void tbSortNum_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
