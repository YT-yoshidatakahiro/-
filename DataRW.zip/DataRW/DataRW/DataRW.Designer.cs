﻿namespace DataRW
{
    partial class DataRW
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.DGVData = new System.Windows.Forms.DataGridView();
            this.tbFile = new System.Windows.Forms.TextBox();
            this.cbFile = new System.Windows.Forms.ComboBox();
            this.btnRead = new System.Windows.Forms.Button();
            this.btnWrite = new System.Windows.Forms.Button();
            this.tbWriteName = new System.Windows.Forms.TextBox();
            this.btnOpenDir = new System.Windows.Forms.Button();
            this.btnIncCol = new System.Windows.Forms.Button();
            this.btnDecCol = new System.Windows.Forms.Button();
            this.tbColNum = new System.Windows.Forms.TextBox();
            this.tbColName = new System.Windows.Forms.TextBox();
            this.btnSetCol = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.DGVSort = new System.Windows.Forms.DataGridView();
            this.tbSortNum = new System.Windows.Forms.TextBox();
            this.btnSortRun = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.DGVData)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGVSort)).BeginInit();
            this.SuspendLayout();
            // 
            // DGVData
            // 
            this.DGVData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVData.Location = new System.Drawing.Point(12, 87);
            this.DGVData.Name = "DGVData";
            this.DGVData.ReadOnly = true;
            this.DGVData.RowTemplate.Height = 21;
            this.DGVData.Size = new System.Drawing.Size(564, 204);
            this.DGVData.TabIndex = 0;
            this.DGVData.TabStop = false;
            this.DGVData.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVData_CellContentClick);
            // 
            // tbFile
            // 
            this.tbFile.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbFile.Location = new System.Drawing.Point(12, 341);
            this.tbFile.Name = "tbFile";
            this.tbFile.Size = new System.Drawing.Size(263, 39);
            this.tbFile.TabIndex = 1;
            this.tbFile.TabStop = false;
            this.tbFile.Text = "読込ファイル名.csv";
            this.tbFile.TextChanged += new System.EventHandler(this.tbFile_TextChanged);
            // 
            // cbFile
            // 
            this.cbFile.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.cbFile.FormattingEnabled = true;
            this.cbFile.Location = new System.Drawing.Point(12, 390);
            this.cbFile.Name = "cbFile";
            this.cbFile.Size = new System.Drawing.Size(263, 39);
            this.cbFile.TabIndex = 2;
            this.cbFile.TabStop = false;
            this.cbFile.Text = "読込ファイル一覧";
            this.cbFile.SelectedIndexChanged += new System.EventHandler(this.cbFile_SelectedIndexChanged);
            // 
            // btnRead
            // 
            this.btnRead.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnRead.Location = new System.Drawing.Point(534, 297);
            this.btnRead.Name = "btnRead";
            this.btnRead.Size = new System.Drawing.Size(43, 135);
            this.btnRead.TabIndex = 3;
            this.btnRead.TabStop = false;
            this.btnRead.Text = "読込";
            this.btnRead.UseVisualStyleBackColor = true;
            this.btnRead.Click += new System.EventHandler(this.btnRead_Click);
            // 
            // btnWrite
            // 
            this.btnWrite.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnWrite.Location = new System.Drawing.Point(814, 297);
            this.btnWrite.Name = "btnWrite";
            this.btnWrite.Size = new System.Drawing.Size(38, 90);
            this.btnWrite.TabIndex = 4;
            this.btnWrite.Text = "書込";
            this.btnWrite.UseVisualStyleBackColor = true;
            this.btnWrite.Click += new System.EventHandler(this.btnWrite_Click);
            // 
            // tbWriteName
            // 
            this.tbWriteName.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbWriteName.Location = new System.Drawing.Point(595, 348);
            this.tbWriteName.Name = "tbWriteName";
            this.tbWriteName.Size = new System.Drawing.Size(213, 39);
            this.tbWriteName.TabIndex = 5;
            this.tbWriteName.TabStop = false;
            this.tbWriteName.Text = "書込ファイル名.csv";
            this.tbWriteName.TextChanged += new System.EventHandler(this.tbWriteName_TextChanged);
            // 
            // btnOpenDir
            // 
            this.btnOpenDir.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnOpenDir.Location = new System.Drawing.Point(12, 296);
            this.btnOpenDir.Name = "btnOpenDir";
            this.btnOpenDir.Size = new System.Drawing.Size(263, 39);
            this.btnOpenDir.TabIndex = 6;
            this.btnOpenDir.TabStop = false;
            this.btnOpenDir.Text = "読込書込先フォルダ確認";
            this.btnOpenDir.UseVisualStyleBackColor = true;
            this.btnOpenDir.Click += new System.EventHandler(this.btnOpenDir_Click);
            // 
            // btnIncCol
            // 
            this.btnIncCol.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnIncCol.Location = new System.Drawing.Point(281, 296);
            this.btnIncCol.Name = "btnIncCol";
            this.btnIncCol.Size = new System.Drawing.Size(114, 38);
            this.btnIncCol.TabIndex = 10;
            this.btnIncCol.TabStop = false;
            this.btnIncCol.Text = "列数増";
            this.btnIncCol.UseVisualStyleBackColor = true;
            this.btnIncCol.Click += new System.EventHandler(this.btnIncCol_Click_1);
            // 
            // btnDecCol
            // 
            this.btnDecCol.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnDecCol.Location = new System.Drawing.Point(414, 295);
            this.btnDecCol.Name = "btnDecCol";
            this.btnDecCol.Size = new System.Drawing.Size(111, 39);
            this.btnDecCol.TabIndex = 11;
            this.btnDecCol.TabStop = false;
            this.btnDecCol.Text = "列数減";
            this.btnDecCol.UseVisualStyleBackColor = true;
            this.btnDecCol.Click += new System.EventHandler(this.btnDecCol_Click);
            // 
            // tbColNum
            // 
            this.tbColNum.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbColNum.Location = new System.Drawing.Point(281, 340);
            this.tbColNum.Name = "tbColNum";
            this.tbColNum.Size = new System.Drawing.Size(114, 39);
            this.tbColNum.TabIndex = 12;
            this.tbColNum.TabStop = false;
            this.tbColNum.Text = "列番号指定";
            this.tbColNum.TextChanged += new System.EventHandler(this.tbColNum_TextChanged);
            // 
            // tbColName
            // 
            this.tbColName.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbColName.Location = new System.Drawing.Point(414, 340);
            this.tbColName.Name = "tbColName";
            this.tbColName.Size = new System.Drawing.Size(114, 39);
            this.tbColName.TabIndex = 13;
            this.tbColName.TabStop = false;
            this.tbColName.Text = "列名";
            this.tbColName.TextChanged += new System.EventHandler(this.tbColName_TextChanged);
            // 
            // btnSetCol
            // 
            this.btnSetCol.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSetCol.Location = new System.Drawing.Point(281, 389);
            this.btnSetCol.Name = "btnSetCol";
            this.btnSetCol.Size = new System.Drawing.Size(244, 43);
            this.btnSetCol.TabIndex = 14;
            this.btnSetCol.TabStop = false;
            this.btnSetCol.Text = "列設定";
            this.btnSetCol.UseVisualStyleBackColor = true;
            this.btnSetCol.Click += new System.EventHandler(this.btnSetCol_Click);
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnClose.Location = new System.Drawing.Point(689, 9);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(163, 36);
            this.btnClose.TabIndex = 15;
            this.btnClose.TabStop = false;
            this.btnClose.Text = "閉じる";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // DGVSort
            // 
            this.DGVSort.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGVSort.Location = new System.Drawing.Point(595, 87);
            this.DGVSort.Name = "DGVSort";
            this.DGVSort.ReadOnly = true;
            this.DGVSort.RowTemplate.Height = 21;
            this.DGVSort.Size = new System.Drawing.Size(257, 204);
            this.DGVSort.TabIndex = 16;
            this.DGVSort.TabStop = false;
            this.DGVSort.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVSort_CellContentClick);
            // 
            // tbSortNum
            // 
            this.tbSortNum.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbSortNum.Location = new System.Drawing.Point(595, 298);
            this.tbSortNum.Name = "tbSortNum";
            this.tbSortNum.Size = new System.Drawing.Size(113, 39);
            this.tbSortNum.TabIndex = 17;
            this.tbSortNum.TabStop = false;
            this.tbSortNum.Text = "列番号指定";
            this.tbSortNum.TextChanged += new System.EventHandler(this.tbSortNum_TextChanged);
            // 
            // btnSortRun
            // 
            this.btnSortRun.Font = new System.Drawing.Font("メイリオ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnSortRun.Location = new System.Drawing.Point(714, 297);
            this.btnSortRun.Name = "btnSortRun";
            this.btnSortRun.Size = new System.Drawing.Size(94, 39);
            this.btnSortRun.TabIndex = 18;
            this.btnSortRun.TabStop = false;
            this.btnSortRun.Text = "並替";
            this.btnSortRun.UseVisualStyleBackColor = true;
            this.btnSortRun.Click += new System.EventHandler(this.btnSortRun_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("メイリオ", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label1.Location = new System.Drawing.Point(12, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(207, 36);
            this.label1.TabIndex = 19;
            this.label1.Text = "並替前読込データ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("メイリオ", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label2.Location = new System.Drawing.Point(589, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(207, 36);
            this.label2.TabIndex = 20;
            this.label2.Text = "並替後読込データ";
            // 
            // DataRW
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(871, 460);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSortRun);
            this.Controls.Add(this.tbSortNum);
            this.Controls.Add(this.DGVSort);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSetCol);
            this.Controls.Add(this.tbColName);
            this.Controls.Add(this.tbColNum);
            this.Controls.Add(this.btnDecCol);
            this.Controls.Add(this.btnIncCol);
            this.Controls.Add(this.btnOpenDir);
            this.Controls.Add(this.tbWriteName);
            this.Controls.Add(this.btnWrite);
            this.Controls.Add(this.btnRead);
            this.Controls.Add(this.cbFile);
            this.Controls.Add(this.tbFile);
            this.Controls.Add(this.DGVData);
            this.Name = "DataRW";
            this.Text = "DataRW";
            this.Load += new System.EventHandler(this.DataRW_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGVData)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGVSort)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView DGVData;
        private System.Windows.Forms.TextBox tbFile;
        private System.Windows.Forms.ComboBox cbFile;
        private System.Windows.Forms.Button btnRead;
        private System.Windows.Forms.Button btnWrite;
        private System.Windows.Forms.TextBox tbWriteName;
        private System.Windows.Forms.Button btnOpenDir;
        private System.Windows.Forms.Button btnIncCol;
        private System.Windows.Forms.Button btnDecCol;
        private System.Windows.Forms.TextBox tbColNum;
        private System.Windows.Forms.TextBox tbColName;
        private System.Windows.Forms.Button btnSetCol;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.DataGridView DGVSort;
        private System.Windows.Forms.TextBox tbSortNum;
        private System.Windows.Forms.Button btnSortRun;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

